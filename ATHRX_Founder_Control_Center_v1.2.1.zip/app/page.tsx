
export default function Home() {
  return (
    <main style={{ padding: 40 }}>
      <h1>ATHRX — Founder Control Center</h1>
      <p>System is running.</p>
    </main>
  );
}
